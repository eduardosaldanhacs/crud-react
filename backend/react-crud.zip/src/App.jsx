import { useEffect, useState } from "react";
import Funcionarios from "./components/Funcionarios";
import "./App.css";
import FuncionarioForm from "./components/FuncionarioForm";

function App() {
  const [funcionarios, setFuncionarios] = useState([
    JSON.parse(localStorage.getItem("funcionarios")) || [],
  ]);

  async function onExcluirFuncionario(id) {
    try {
      //tento acessar a api
      const response = await fetch(
        `http://localhost/api/funcionarios.php?id=${id}`,
        {
          method: "DELETE",
        }
      );
      //armazeno o resultado numa variavel
      const result = await response.json();
      //se o status da api for success
      if (result.status == "success") {
        //atualizo o state de funcionarios com todos eles menos o que tem o id que será deletado
        setFuncionarios(
          funcionarios.filter((funcionario) => funcionario.id !== id)
        );
      } else {
        console.log("Erro ao deletar");
      }
    } catch (error) {
      console.log(error);
    }
  }

  async function onCadastroFuncionario(nome, cargo, salario, dataAdmissao) {
    try {
      const response = await fetch("http://localhost/api/funcionarios.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome: nome,
          cargo: cargo,
          salario: salario,
          dataAdmissao: dataAdmissao,
        }),
      });

      const result = await response.json();
      console.log(result);

      if (result.status === "success") {
        setFuncionarios([...funcionarios, result.funcionario]);
        // aqui depende do que sua API retorna ("data" ou "funcionario")
      }
    } catch (error) {
      console.log(error);
    }
  }

  // async function onSalvarFuncionario() {

  // }

  useEffect(() => {
    const fetchFuncionarios = async () => {
      //CHAMAR A API
      const response = await fetch("http://localhost/api/funcionarios.php", {
        method: "GET",
      });
      const data = await response.json();
      console.log(data);
      setFuncionarios(data);
    };
    fetchFuncionarios();
  }, []);

  return (
    <div className="container mt-5">
      <h1 className="text-primary">Lista de funcionarios</h1>
      <Funcionarios
        funcionarios={funcionarios}
        onExcluirFuncionario={onExcluirFuncionario}
      />
      <FuncionarioForm onCadastroFuncionario={onCadastroFuncionario} />
    </div>
  );
}

export default App;
