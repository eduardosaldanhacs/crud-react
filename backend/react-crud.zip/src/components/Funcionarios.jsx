function Funcionarios({funcionarios, onExcluirFuncionario }) {
  return (
    <div className="row">
      {funcionarios.map((funcionario) => (
        <div className="col-md-4 mb-2" key={funcionario.id}>
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">{funcionario.nome}</h5>
              <p className="card-text">Cargo: {funcionario.cargo}</p>
            </div>
          </div>
          <button
            className="btn btn-outline-danger mt-2"
            onClick={() => onExcluirFuncionario(funcionario.id)}
          >
            Excluir
          </button>
        </div>
      ))}
    </div>
  );
}
export default Funcionarios;
