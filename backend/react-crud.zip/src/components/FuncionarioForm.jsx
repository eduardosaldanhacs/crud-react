import { useState } from "react";

function FuncionarioForm({onCadastroFuncionario}) {
  const [nome, setNome] = useState("");
  const [cargo, setCargo] = useState("");
  const [salario, setSalario] = useState("");
  const [dataAdmissao, setDataAdmissao] = useState("");

  const verificarCampos = (e) => {
    e.preventDefault();
    if (!nome || !cargo || !salario || !dataAdmissao) {
      alert("Preencha todos os campos!");
    } else {
      onCadastroFuncionario(nome, cargo, salario, dataAdmissao);
      setNome("");
      setCargo("");
      setSalario("");
      setDataAdmissao("");
    }
  };

  return (
    <form
      className="row justify-content-center align-items-center mt-4"
      onSubmit={verificarCampos}
    >
      <div className="col-6 bg-light py-3">
        <div>
          <label htmlFor="" className="form-label">
            Nome
          </label>
          <input
            type="text"
            className="form-control"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="" className="form-label">
            Cargo
          </label>
          <input
            type="text"
            className="form-control"
            value={cargo}
            onChange={(e) => setCargo(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="" className="form-label">
            Salário
          </label>
          <input
            type="text"
            className="form-control"
            value={salario}
            onChange={(e) => setSalario(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="" className="form-label">
            Data de admissão
          </label>
          <input
            type="date"
            className="form-control"
            value={dataAdmissao}
            onChange={(e) => setDataAdmissao(e.target.value)}
          />
        </div>

        <div className="text-center mt-3">
          <button className="btn btn-primary" type="submit">
            Salvar
          </button>
        </div>
      </div>
    </form>
  );
}
export default FuncionarioForm;
